package assignment1;

//  Task 10 :  Write a program which will break the current execution if it find “Selenium” Input – [“Java”,”JavaScript”,”Selenium”,”Python”,”Mukesh”]

public class A110 {

	public static void main(String[] args) 
	{
		String [] input = new String[5];
		input[0] = "Java";
		input[1] = "JavaScript";
		input[2] = "Selenium";
		input[3] = "Python";
		input[4] = "Mukesh";
		
		for(int i =0; i< 5; i++)
		{
			if(input[i] == "Selenium")
				break;
			else
				System.out.println(input[i]);
		}

	}

}
