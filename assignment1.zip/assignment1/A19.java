package assignment1;

import java.util.Scanner;

//Write a program which will break the current execution if it find number 85 Input – [12,34,66,85,900]

public class A19 {

	public static void main(String[] args)
	{
		int [] input = new int[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter students marks for five subjects : ");
		for(int i = 0; i<5; i++)
		{
				input[i] = sc.nextInt();
		}
		
		for(int i =0; i< 5; i++)
		{
			if(input[i] == 85)
				break;
			else
				System.out.println(input[i]);
		}
	}//end main

}//end class
