package assignment1;

//Task 5 : Write a program to print all odd numbers from 1-50

public class A15 {

	public static void main(String[] args) {
		
		System.out.println("Odd Numbers from 1 to 50 ");
		for(int i = 1; i<=50; i++) 
		{
			if(i%2 != 0)
				System.out.println(i);
		}

	}

}
