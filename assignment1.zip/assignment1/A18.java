package assignment1;

import java.util.Scanner;

// Task 8- Write a program to print below students marks who have scored above 80, Example- 78,12,89,55,35 Output-  78,89

public class A18 
{

	public static void main(String[] args)
	{
		int [] input = new int[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter students marks for five subjects : ");
		for(int i = 0; i<5; i++)
		{
			input[i] = sc.nextInt();
		}
		
		System.out.println("Marks above 80 are : ");
		for(int i = 0; i<5; i++) 
		{
			if(input[i]>80) 
			{
				System.out.println(input[i]);	
			}
		}
	
	}//end main

}//END Class A18
