package assignment1;

// Task 4 :Write a program to print all even numbers from 1-200

public class A14 {

	public static void main(String[] args) {
		
		System.out.println("Even Numbers from 1 to 200 ");
		for(int i = 1; i<=200; i++) 
		{
			if(i%2 == 0)
				System.out.println(i);
		}
	}

}
