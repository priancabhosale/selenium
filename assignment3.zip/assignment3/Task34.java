package assignment3;
//Write a program which will print sum of all numbers which is stored in list.
import java.util.*;

public class Task34
{
	public static void main(String args [])
	{
		//create Integer list
		List <Integer> intList = new ArrayList<Integer>();
		
		//add elements to the list
		intList.add(9);
		intList.add(8);
		intList.add(7);
		intList.add(6);
		intList.add(5);
		intList.add(4);
		
		// create iterator
		
		Iterator <Integer> iterate = intList.iterator();
		
		int sum = 0;
		 
		// Display List using iterator
		while(iterate.hasNext())
		{
			int i = iterate.next();
			sum = sum +i;
		}//end while
		
		System.out.println("Sum of all the elements in the list = " + sum);
	}//end main
	
}//end class Task34
