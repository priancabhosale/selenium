package assignment3;
//Write a program which will pick the values from Array and Store them List.

import java.util.*;

public class Task35 
{
	public static void main(String args [])
	{
		String friends[] = {"Happy","Jolly","Bubli","Teddy","Pinky"};
		
		System.out.println("Array element"+ Arrays.toString(friends));
		
		List <String> l1 = ArrayToListConversion(friends);
		
		System.out.println("List Elements: " + l1);  
	}//end main()
	
	public static <T> List<T> ArrayToListConversion(T friends[])   
	{   
		List<T> list = Arrays.asList(friends);   
		//returns the list  
		return list;      
	}//end ArrayToList()
	
}//end class Task35
