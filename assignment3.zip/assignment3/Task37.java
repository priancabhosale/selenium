package assignment3;
import java.util.*;

/*Write a program which will display true if list contains Mobile Automation else prints false
List  - Web Automation, API Automation, Mobile Automation.
Output – True */ 

public class Task37 
{

	public static void main(String[] args)
	{
		ArrayList<String> namesList = new ArrayList<String>(Arrays.asList( "Web Automation", "API Automation", 
																		"Mobile Automation"));
		System.out.println(namesList);
		System.out.println("Whether list contains Mobile Automation? ");
		System.out.println(namesList.contains("Mobile Automation"));
	}
//end main
}//end class Task37
