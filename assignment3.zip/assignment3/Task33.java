package assignment3;
// Write a program which can store List of Integer values and print all the values using iterator
import java.util.*;

public class Task33 
{
	public static void main(String args [])
	{
		//create Integer list
		List <Integer> intList = new ArrayList<Integer>();
		
		//add elements to the list
		intList.add(9);
		intList.add(8);
		intList.add(7);
		intList.add(6);
		intList.add(5);
		intList.add(4);
		
		// create iterator
		
		Iterator <Integer> iterate = intList.iterator();
		
		// Display List using iterator
		while(iterate.hasNext())
		{
			int i = iterate.next();
			
			System.out.println(i);
		}//end while
	}//end main
	
}// end class Task33
