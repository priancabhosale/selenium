package assignment3;

//Write a program which can store List of Integer values and print all the values using for each loop.

import java.util.*;

public class Task32 
{
	public static void main(String args [])
	{
		//create Integer list
		List <Integer> intList = new ArrayList<Integer>();
		
		//add elements to the list
		intList.add(21);
		intList.add(31);
		intList.add(41);
		intList.add(51);
		intList.add(561);
		intList.add(666);
		
		// Display List using for each loop
		System.out.println("List Elements are: ");
		for(Integer i:intList)
		{
			System.out.println(i);
		}//end for loop
		
	}//end main()


}
