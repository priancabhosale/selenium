package assignment3;
// Write a program which can store List of Integer values and print all the values using for loop.
import java.util.*;

public class Task31 
{
	public static void main(String args [])
	{
		//create Integer list
		List <Integer> intList = new ArrayList<Integer>();
		
		//add elements to the list
		intList.add(11);
		intList.add(22);
		intList.add(33);
		intList.add(44);
		intList.add(55);
		intList.add(66);
		
		// Display List using for loop
		System.out.println("List Elements are: ");
		for(int i = 0; i<intList.size(); i++)
		{
			System.out.println(intList.get(i));
		}//end for loop
		
	}//end main()
}// end class Task31
