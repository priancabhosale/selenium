package assignment3;

/*Create a list of numbers 33,44,55,66,77,88 and perform below operation
	Remove second element from list using index
	Remove second element from list using value
	Add 90 at index 3
	Get the length of list
	Print all values from list using any values
	Convert List into array.
*/

import java.util.*;

public class Task36 {

	public static void main(String[] args)
	{
		//create Integer list
		ArrayList <Integer> intList = new ArrayList<Integer>();
				
		//add elements to the list
		intList.add(33);
		intList.add(44);
		intList.add(55);
		intList.add(66);
		intList.add(77);
		intList.add(88);
				
		// Display original list
		System.out.println("Original List:");
		System.out.println(intList);
		
		//Remove second element from list using index
		System.out.println("After removing second element by index:");
		intList.remove(1);
		System.out.println(intList);
		
		//Remove second element from list using value
		System.out.println("After removing second element by value:");
		intList.remove(Integer.valueOf(55));
		System.out.println(intList);
		
		//Add 90 at index 3
		System.out.println("After adding 90 at index 3:");
		intList.add(3, 90);;
		System.out.println(intList);
		
		//list length
		System.out.println("Length if the list:"+intList.size() );
		
		//print all values in list
		System.out.println("Entire list is"+intList);
		
		//Convert List into array
		int listLength = intList.size();
		int [] listArray = new int[ listLength ];
		
		for(int i = 0;i<listLength;i++)
		{
			listArray[i]=intList.get(i);
		}	
		
		System.out.println("After converting List into an Array");  
		
	    for (int j = 0; j < listArray.length; j++) 
	    {  
	             System.out.println((j+1)+" element of the array is "+ listArray[j]);
	    }
	    
	}//end main()

}//end class Task36
