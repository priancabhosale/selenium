package assignment4;
import java.util.*;

/*
 	Create a list which can accept another list as an element.
        List 1- 11,22,33
	    List 2-  9,19,29	
	    List 3-  7,17,27
	    
	    Hint - ArrayList<ArrayList<Integer>> l1=new ArrayList<>(); 		
 */
public class ListInList 
{

	public static void main(String[] args) 
	{
		ArrayList <Integer> l1 = new ArrayList();
		ArrayList <Integer> l2 = new ArrayList();
		ArrayList <Integer> l3 = new ArrayList();
		
		l1.add(11);
		l1.add(22);
		l1.add(33);
		
		l2.add(9);
		l2.add(19);
		l2.add(29);
		
		l3.add(7);
		l3.add(17);
		l3.add(27);
		
		ArrayList<ArrayList<Integer>> comboList=new ArrayList<>();
 
        comboList.add(l1);
        comboList.add(l2);
        comboList.add(l3);
 		
        System.out.println("List 1: " + l1);
        System.out.println("List 2: " + l2);
        System.out.println("List 3: " + l3);
        System.out.println("List in list" + comboList);
	}//end main

}// end class ListInList
