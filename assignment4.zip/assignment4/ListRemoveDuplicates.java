package assignment4;
import java.util.*;
import java.util.stream.Collectors;
/*
  Write a program that will remove duplicate values from List
	Input – Java, TestNG, Maven, Java, 
	Output – Java, TestNG, Maven
 */
public class ListRemoveDuplicates 
{

	public static void main(String[] args) 
	{
		//Create list and add elements
		List <String> list1 = new ArrayList();
		list1.add("Java");
		list1.add("TestNG");
		list1.add("Maven");
		list1.add("Java");
		
		System.out.println("Original list with duplicates : "+ list1);
		
		List<String> newList = list1.stream().distinct().collect(Collectors.toList());
		System.out.println("Original list with duplicates : "+ newList);
		
	}//end main

}// end class ListRemoveDuplicates 
