package assignment4;
import java.util.stream.Stream;
import java.util.*;

/*
 	Write a program which will accept List of String and produce another List of string 
 		of which will have only values which starts with git
	Input – Git, Github, GitLab,GitBash, Selenium, Java, Maven
	Output- Git, Github, Gitlab, GitBash
 */

public class ListWithPrefix {

	public static void main(String[] args) 
	{
		//Create arrayList 
				List <String> arrayList = new ArrayList();
				List <String> arrayList2 = new ArrayList();
				
				 arrayList.add("Git");
				 arrayList.add("Github");
				 arrayList.add("GitLab"); 
				 arrayList.add("GitBash"); 
				 arrayList.add("Selenium"); 
				 arrayList.add("Java");
				 arrayList.add("Maven");
				 
				 //Display original list
				 System.out.println("Oririnal List elements : " + arrayList);
				 
				 //Check which Stings start with "Git"
				 String prefix = "Git";
				 
				 for(String str:arrayList)
				 {
					 if (Stream.of(prefix).anyMatch(str::startsWith))
						 arrayList2.add(str);
				 }//end for
				 
				//Display list with elements starting with"Git"
				 System.out.println("New List with strings starting with Git : " + arrayList2);

	}

}
