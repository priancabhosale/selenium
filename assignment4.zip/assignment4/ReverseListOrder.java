package assignment4;
import java.util.*;
/*
 Create a list of String and print the values in reverse order
 Input – Java, Selenium, TestNG, Git, Github
 Output- Github, Git, TestNG, Selenium, Java
 */

public class ReverseListOrder
{
	public static void main(String[] args) 
	{
		//Create arrayList 
		ArrayList arrayList = new ArrayList();
		 
		 arrayList.add("Java");
		 arrayList.add("Selenium");
		 arrayList.add("TestNG"); 
		 arrayList.add("Git"); 
		 arrayList.add("Github"); 
		 
		 //Display original list
		 System.out.println("ArrayList elements : " + arrayList);
		 
		 Collections.reverse(arrayList);
		 
		//Display Reverse list
		 System.out.println("ArrayList elements after reversing order : " + arrayList);

	}//end main()
} //end class ReverseListOrder
