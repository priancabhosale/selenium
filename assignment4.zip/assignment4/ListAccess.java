package assignment4;
import java.util.*;
/*
 	Create a list of values and print the second element, second last element.
	Input – 10,45, 90,45, 23, 90, 44
	Output – 45,90
 */

public class ListAccess {

	public static void main(String[] args) 
	{
		List <Integer> intList = new ArrayList();
		intList.add(10);
		intList.add(45);
		intList.add(90);
		intList.add(45);
		intList.add(23);
		intList.add(90);
		intList.add(44);
		
		System.out.println("Original List: " + intList);
		
		
		System.out.println("Second Element and second last element from list: "+ intList.get(1) 
								+ "," + intList.get(intList.size()-2));

	}//end Main()

}//End class ListAccess
