package assignment2;
import java.util.*;
//Store all trainer information in Array.

public class Task2
{
	
	public static void main(String[] args)
	{
		Task2 T = new Task2();
		Object [][] trainerinfo= {{"Mukesh","Testing","mukesh@gmail.com",1},
			      				  {"Hitesh","Dev","mukesh@gmail.com",2},
			      				  {"Mukesh","Devops","mukesh@gmail.com",3}
			      	              };
		//System.out.println(Arrays.deepToString(trainerinfo)); //to display data in an array
		
		System.out.println("Task 2"+ "\n"+ "Employee details:");
		
		for(Object [] i: trainerinfo) 
		{
			for(Object j: i)
				System.out.println(j);
		}
	}

}
