package assignment2;
/*Task 1- Create a class name as “Trainer” which will have 4 fields name, department ,  email, id. Trainer can teach Selenium, DevOps, Web Development.
Note- use method, constructor */

public class Trainer {
	String name,department,email;
	int id;
	
	public void dispaly()
	{
		System.out.println("Nmae : " + name + "\n" + "Department : "+ department + "\n"+ 
							"Email : " + email + "\n" + "ID: " +id);
	}
	public static void main(String[] args) {
		Trainer T1 = new Trainer();
		Trainer T2 = new Trainer();
		Trainer T3 = new Trainer();
		
		T1.name = "Mukesh";
		T1.department = "Testing";
		T1.email = "mukesh@gmail.com";
		T1.id = 1;
		
		T2.name = "Hitesh";
		T2.department = "Dev";
		T2.email = "mukesh@gmail.com";
		T2.id = 2;
		
		T3.name = "Mukesh";
		T3.department = "DevOps";
		T3.email = "mukesh@gmail.com";
		T3.id = 3;
		
		System.out.println("Task 1");
		System.out.println("Trainer Details are as follows: "+  "\n");
		T1.dispaly();
		T2.dispaly();
		T3.dispaly();
	}

}
