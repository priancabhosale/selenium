package assignment2;
import java.util.*;

class Student2 
{
	public String name,email,address,status,phonenumber;
	
	public void setName(String name) 
	{
		this.name = name;
	}

	public void setEmail(String email) 
    {
    	this.email = email;
	}
    
	public void setAddress(String address) 
    {
    	this.address = address;
	}
    
	public void setStatus(String status) 
    {
		this.status = status;
	}
    
	public void setPhone(String phonenumber) 
    {
		this.phonenumber = phonenumber;
	}
    
    //get
    
    public String getName() 
	{
		return name;
	}
    
	public String getEmail() 
    {
	    return email;
	}
    public String getAddress() 
    {
    	return address;
	}
    public String getStatus() 
    {
		return status;
	}
    public String getPhone() 
    {
		return phonenumber;
	}
    
    public Student2()
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.print("Enter Name");
    	this.setName(sc.next());
    	
    	System.out.print("Enter Email");
    	this.setEmail(sc.next());
    	
    	System.out.print("Enter Address");
    	this.setAddress(sc.next());
    	
    	System.out.print("Enter Status(pass/fail)");
    	this.setStatus(sc.next());
    	
    	System.out.print("Enter Phone Number");
    	this.setPhone(sc.next());
    }//end constructor
}//end class Student2

public class Student1
{
    	public static void main (String[] args)
    	{ 
    		Scanner sc1 = new Scanner(System.in);
    		System.out.print("How many students information you want to store:");
    		int count = sc1.nextInt();
    		
    		Student2 [] arrayStudents = new Student2[count];
    		
    		//add students data to array
    		for(int i = 0; i<count; i++)
    		{
    			Student2 s1 = new Student2();
    			arrayStudents[i] = s1;
    		}
    		
    		//display data of student requested by user
    		System.out.print("Which student data you wanna check (enter number) : ");
    		int choice = sc1.nextInt();
    		Student2 s = arrayStudents[choice];
			System.out.println(s.getName()+ ","+ s.getEmail()+ ","+ s.getAddress()+
					            ","+ s.getStatus()+ "," +s.getPhone());
    		/*/display data of student
    		for(int i = 0; i<count; i++)
    		{
    			Student2 s = arrayStudents[i];
    			System.out.println(s.getName()+ ","+ s.getEmail()+ ","+ s.getAddress()+
    					            ","+ s.getStatus()+ "," +s.getPhone());
    		} */
    	  		
    	}//end main
}//end class Student1


